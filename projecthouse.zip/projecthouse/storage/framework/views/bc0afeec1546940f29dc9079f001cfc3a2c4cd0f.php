<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-0 bg-dark">
	<a href="/">
	<img src=<?php echo e(asset('/images/icon.png')); ?> height="35px" >
      <a class="link my-0 mr-md-auto font-weight-normal" href="/">Modern Homes</h5>
	      <nav class="nav-link">
		        <a class="active" href="/home">Home</a>
		        <a class="p-2 link" href="/aboutus">About us</a>
		        <a class="p-2 link" href="/ourteam">Our team</a>
		        <a class="p-2 link" href="/contactus">Contact us</a>
	      </nav>
 </div>