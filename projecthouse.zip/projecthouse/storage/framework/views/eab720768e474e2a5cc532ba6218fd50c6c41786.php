<?php $__env->startSection('content'); ?>

<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-0 bg-dark">
	<a href="/">
	<img src=<?php echo e(asset('/images/icon.png')); ?> height="35px" >
      <a class="link my-0 mr-md-auto font-weight-normal" href="/">Modern Homes</h5>
	      <nav class="nav-link">
		        <a class="p-2 link" href="/home">Home</a>
		        <a class="active" href="/aboutus">Our services</a>
		        <a class="p-2 link" href="/ourteam">Our team</a>
		        <a class="p-2 link" href="/contactus">Contact us</a>
	      </nav>
 </div>

 <div class="section">
	<div class="container">
		<h1 class="services">OUR SERVICES</h1>

		<div class="section">
			<h5 class="heading">GENERAL CONSTRUCTION</h3>
			<p class="services">With almost 30 years of experience in the construction field, we have undertaken a tremendous amount of projects so far. One of our best and yet, beautiful experiences had to be the construction of Community Houses, Private Homes, Apartment Complexes, and other buildings. We strive to be the preeminent provider of building construction services and hence we promise to offer you with the service you desire. We work along with our expert engineers and architectures to build individual homes that are structurally strong. We consist of skilled manpower only that is willing to put the effort to make a difference.</p>
		</div>
		<div class="section">
			<h5 class="heading">DESIGN-BUILD</h3>
			<p class="services"> We have highly skilled teams to design, build and manage our projects. We do not compromise when it comes to the quality of the product. The equipment and tools we use are directly from the vendor, making it more reliable and cost-effective. Modern homes excel in developing innovative concepts to build better and stronger homes in our community. We have experienced, creative and flexible teams which makes our team different than anybody else.</p>
		</div>
		<div class="section">
			<h5 class="heading">RENOVATION</h3>
			<p class="services">Along with the project of construction, we also provide services in reconstructing buildings. Our goal is to make the citizens feel safer where they live. We not only construct earthquake resistance buildings but we also renovate buildings upon customers demand.</p>
		</div>
      			
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>