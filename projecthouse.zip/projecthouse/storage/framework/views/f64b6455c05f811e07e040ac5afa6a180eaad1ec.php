<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-0 bg-dark">
    <a href="/">
       <img src=<?php echo e(asset('/images/icon.png')); ?> height="35px" >
           <a class="link my-0 mr-md-auto font-weight-normal" href="/">Modern Homes</h5>
             <nav class="nav-link">
               <a class="p-2 link" href="/home">Home</a>
               <a class="p-2 link" href="/aboutus">Our services</a>
               <a class="p-2 link" href="/ourteam">Our team</a>
               <a class="active" href="/contactus">Contact us</a>
              </nav>
  </div>

<?php $__env->startSection('content'); ?>

	<div class="container">
		<div class="section">
			<hr>
			<h3 class="text-muted">Address</h3>
			<p class="lead text-muted">Sukedhara </br> Kathmandu, Nepal </br></p>
			<h3 class="text-muted">Email</h3>
			<a href="mailto:kiyu567@gmail.com"><p class="lead text-muted">kiyu567@gmail.com</p></a>
			<h3 class="text-muted">Phone</h3>
			<p class="lead text-muted"> +(977) 980-101-6040</p>
		</div>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>