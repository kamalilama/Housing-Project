<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-0 bg-dark">
    <a href="/">
       <img src=<?php echo e(asset('/images/icon.png')); ?> height="35px" >
           <a class="link my-0 mr-md-auto font-weight-normal" href="/">Modern Homes</h5>
             <nav class="nav-link">
               <a class="p-2 link" href="/home">Home</a>
               <a class="p-2 link" href="/aboutus">Our ervices</a>
               <a class="active" href="/ourteam">Our team</a>
               <a class="p-2 link" href="/contactus">Contact us</a>
              </nav>
  </div>

<?php $__env->startSection('content'); ?>

<div class="section">
	<hr>

	<img src=<?php echo e(asset('/images/team.jpg')); ?> height="500px" alt="Team" class="center">
</div>

<div class="section">
	<div class="container">
		<h1 class="jumbotron-heading">OUR STORY</h1>

		<div class="section">
			<p class="lead text-muted">Our mission is to work together with our costumers to meet their needs and demands at fair and market competitive price. </br> As you invest your money and time on us, we invest our ideas and concepts in building stronger </br> yet beautiful houses with greater interior and exterior designs.</p>
		</div>
      			
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>