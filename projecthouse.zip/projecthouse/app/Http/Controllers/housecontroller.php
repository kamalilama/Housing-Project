<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class housecontroller extends Controller
{
    public function index()
    {
    	return view('index');
    }

    public function aboutus()
    {
    	return view('layout.aboutus');
    }

    public function ourteam()
    {
    	return view('layout.team');
    }

    public function contactus()
    {
    	return view('layout.contact');
    }
}
