<p class="float-right">
          <a class="text-muted" href="#">Back to top &nbsp &nbsp</a>
        </p>
<footer class="text-muted">
	<hr>
      <div class="container">
        
        <p class="foot">Thank you for visiting our website. </p>
        <div class="container">
		<div class="section">
			<h6 class="text-muted">Address: Sukedhara, Kathmandu, Nepal </br> </h3>
			<a href="mailto:kiyu567@gmail.com"><h6 class="text-muted">Email: kiyu567@gmail.com</h6></a>
			
			<h6 class="text-muted">Phone: +(977) 980-101-6040</h3>
		</div>
	</div>
      </div>
</footer>