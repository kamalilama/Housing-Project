@extends ('welcome')

<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-0 bg-color">
    <a href="/">
       <img src={{ asset('/images/logo.png') }} height="35px" >
           <a class="link my-0 mr-md-auto font-weight-normal" href="/">Modern Homes</h5>
             <nav class="nav-link">
               <a class="active" href="/home">Home</a>
               <a class="p-2 link" href="/aboutus">Our services</a>
               <a class="p-2 link" href="/ourteam">Our team</a>
               <a class="p-2 link" href="/contactus">Contact us</a>
              </nav>
  </div>

@section('content')

	

      <div class="topnav">
      	<section class="text-center">
        <div class="container">
            <a href="#" class="btn btn-secondary my-2">Explore</a>
          </p>
        </div>
      </section>
      	
      </div>

      	<div class="section">
      	<div class="container">
      			<h1 class="jumbotron-heading">Construct your dreams </h1>
      		<p class="lead text-muted">Modern Homes is one of the distinct company that works towards building better community and safer homes. We provide comfort and quality that matches your taste. We encourage you to take a look at our past project and let the quality speak for itself. </p>
      			
      	</div>
      </div>

      <div class="container">
     
 
 
<div class="container gallery-container">
      
    <div class="tz-gallery">

      <div class="section">

        <div class="row mb-3">
            <div class="col-md-4">
                <div class="card">
                    <a class="lightbox" href="images/photo6.jpg">
                    <img src="images/photo6.jpg" alt="Park" class="card-img-top" height="250px">
                    </a>
                </div>
            </div>
             
            <div class="col-md-4">
                <div class="card">
                    <a class="lightbox" href="images/photo1.jpg">
                    <img src="images/photo1.jpg" alt="Park" class="card-img-top" height="250px">
                    </a>
                </div>
            </div>
             
            <div class="col-md-4">
                <div class="card">
                    <a class="lightbox" href="images/photo2.jpg">
                    <img src="images/photo2.jpg" alt="Park" class="card-img-top" height="250px">
                    </a>
                </div>
            </div>
        </div>
        
      </div>

      <div class="section">
        
        <div class="row"> 
            <div class="col-md-4">
                <div class="card">
                    <a class="lightbox" href="images/photo3.jpg">
                    <img src="images/photo3.jpg" alt="Park" class="card-img-top" height="250px">
                    </a>
                </div>
            </div>
             
            <div class="col-md-4">
                <div class="card">
                    <a class="lightbox" href="images/photo4.jpg">
                    <img src="images/photo4.jpg" alt="Park" class="card-img-top" height="250px">
                    </a>
                </div>
            </div>
             
            <div class="col-md-4">
                <div class="card">
                    <a class="lightbox" href="images/photo5.jpg">
                    <img src="images/photo5.jpg" alt="Park" class="card-img-top" height="250px">
                    </a>
                </div>
            </div>
         
        </div>

      </div>  
        
          
  
    </div>
  
</div>

<div class="container">
      <div class="section">
      <p class="lead text-muted">These are samples of our work.</p>
    </div>
            
    </div>
 
</div>      



@endsection