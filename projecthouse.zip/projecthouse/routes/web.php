<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', 'housecontroller@index');

Route::get('/home', 'housecontroller@index');

Route::get('/aboutus', 'housecontroller@aboutus');

Route::get('/ourteam','housecontroller@ourteam');

Route::get('/contactus','housecontroller@contactus');